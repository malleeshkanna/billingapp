const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

const PORT = process.env.PORT || 3652;

const BLOGS_FOLDER = path.join(
    __dirname,
    "blogs"
);

const BLOGS_JSON = path.join(
    __dirname,
    "blogs.json"
);


/*
 * /blogs
 *
 * Serve files from blogs folder.
 *
 * Example:
 * /blogs/my-first-blog.html
 */
app.use(
    "/blogs",
    express.static(BLOGS_FOLDER)
);


/*
 * /all-blogs
 *
 * Return maximum 5 random blogs.
 *
 * Response:
 *
 * Blog Title~blog-slug,Blog Title~blog-slug
 */
app.get("/all-blogs", (req, res) => {

    res.type("text/plain");

    if (!fs.existsSync(BLOGS_JSON)) {
        return res
            .status(500)
            .send("blogs.json not found");
    }

    try {

        const json = fs.readFileSync(
            BLOGS_JSON,
            "utf8"
        );

        const blogs = JSON.parse(json);

        if (!Array.isArray(blogs)) {
            return res
                .status(500)
                .send("Invalid blogs.json");
        }

        const validBlogs = blogs.filter(blog =>
            blog &&
            blog.title !== undefined &&
            blog.slug !== undefined
        );

        const count = Math.min(
            5,
            validBlogs.length
        );

        if (count === 0) {
            return res.send("");
        }

        /*
         * Shuffle blogs
         */
        const shuffled = [...validBlogs];

        for (
            let i = shuffled.length - 1;
            i > 0;
            i--
        ) {

            const j = Math.floor(
                Math.random() * (i + 1)
            );

            [
                shuffled[i],
                shuffled[j]
            ] = [
                shuffled[j],
                shuffled[i]
            ];
        }

        /*
         * Take maximum 5
         */
        const selected = shuffled.slice(
            0,
            count
        );

        /*
         * Convert:
         *
         * title~slug
         */
        const result = selected.map(blog => {

            const title = String(
                blog.title
            ).trim();

            const slug = String(
                blog.slug
            ).trim();

            return `${title}~${slug}`;
        });

        /*
         * Plain text response
         */
        return res.send(
            result.join(",")
        );

    } catch (error) {

        console.error(
            "blogs.json error:",
            error.message
        );

        return res
            .status(500)
            .send("Invalid blogs.json");
    }
});


/*
 * Start server
 */
app.listen(PORT, () => {

    console.log(
        `Server running on port ${PORT}`
    );

});