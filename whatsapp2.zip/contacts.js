module.exports = [
    {
        id: 1,
        name: "Mom",
        phno: "917598516034"
    },
    {
        id: 2,
        name: "Dad",
        phno: "918072269492"
    },
    {
        id: 3,
        name: "Vignesh",
        phno: "919500797743"
    },
    {
        id: 4,
        name: "Vignesh 2",
        phno: "918925377285"
    },
     {
        id: 5,
        name: "Rahuman",
        phno: "918220135064"
    },
     {
        id: 6,
        name: "Malleeshkanna",
        phno: "919087024531"
    },
];