const express = require("express");
const { getArticleImage } = require("./controllers/articleImageController");
const {getNews} = require('./controllers/newsController')
const {getArticle} = require('./controllers/articleController')
const app = express();


app.get("/api/news", getNews);
app.get("/api/article-image", getArticleImage);
app.get("/api/article", getArticle);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});