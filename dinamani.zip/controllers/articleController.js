const axios = require("axios");
const cheerio = require("cheerio");

const getArticle = async (req, res) => {
  try {
    const { slug } = req.query;

    if (!slug) {
      return res.status(400).json({
        error: "slug is required",
      });
    }

    const url = `https://www.dinamani.com${slug}`;

    const { data: html } = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
          "AppleWebKit/537.36 (KHTML, like Gecko) " +
          "Chrome/131.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml",
      },
      timeout: 30000,
    });

    const $ = cheerio.load(html);

    // Headline
    const title = $("h1")
      .first()
      .text()
      .trim();

    // Date
    let date = "";

    $("span").each((_, el) => {
      const text = $(el)
        .text()
        .trim();

      if (text.includes("Updated On")) {
        date = $(el)
          .parent()
          .text()
          .replace("Updated On :", "")
          .trim();
      }
    });

    // Content
    const description = $(".article-links p")
      .map((_, el) => $(el).text().trim())
      .get()
      .filter((text) => text.length > 0)
      .join("\n\n");

    const output = `Headline: ${title}

Date: ${date}

Content:
${description}`;

    res.set("Content-Type", "text/plain; charset=utf-8");

    return res.send(output);

  } catch (error) {
    console.error("Get article error:", error.message);

    return res.status(500).json({
      error: "Failed to fetch article",
      message: error.message,
    });
  }
};

module.exports = {
  getArticle,
};