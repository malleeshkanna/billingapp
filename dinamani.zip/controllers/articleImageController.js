const axios = require("axios");
const cheerio = require("cheerio");
const sharp = require("sharp");

const MAX_WIDTH = 176;
const MAX_HEIGHT = 132;

const getArticleImage = async (req, res) => {
  try {
    const { slug } = req.query;

    if (!slug) {
      return res.status(400).json({
        error: "slug is required",
      });
    }

    const articleUrl = `https://www.dinamani.com${slug}`;

    // Get article HTML
    const { data: html } = await axios.get(articleUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
          "AppleWebKit/537.36 (KHTML, like Gecko) " +
          "Chrome/131.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml",
      },
      timeout: 30000,
    });

    const $ = cheerio.load(html);

    // Find article image
    let imageUrl = $("img[alt='News image']")
      .first()
      .attr("src");

    // Fallback
    if (!imageUrl) {
      imageUrl = $("article img")
        .first()
        .attr("src");
    }

    if (!imageUrl) {
      return res.status(404).json({
        error: "Article image not found",
      });
    }

    // Convert relative URL to absolute URL
    imageUrl = new URL(
      imageUrl,
      "https://www.dinamani.com"
    ).href;

    // Download image
    const { data: imageBuffer } = await axios.get(imageUrl, {
      responseType: "arraybuffer",
      headers: {
        "User-Agent": "Mozilla/5.0",
      },
      timeout: 30000,
    });

    // Resize + compress
    const outputBuffer = await sharp(imageBuffer)
      .resize(MAX_WIDTH, MAX_HEIGHT, {
        fit: "inside",
        position: "centre",
      })
      .jpeg({
        quality: 75,
        progressive: true,
      })
      .toBuffer();

    // Send image
    res.set({
      "Content-Type": "image/jpeg",
      "Content-Length": outputBuffer.length,
      "Cache-Control": "public, max-age=3600",
    });

    return res.send(outputBuffer);

  } catch (error) {
    console.error("Article image error:", error.message);

    return res.status(500).json({
      error: "Failed to get article image",
      message: error.message,
    });
  }
};

module.exports = {
  getArticleImage,
};