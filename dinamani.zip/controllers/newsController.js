const axios = require("axios");
const cheerio = require("cheerio");

const getNews = async (req, res) => {
  try {
    const { data: html } = await axios.get("https://www.dinamani.com/", {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
          "AppleWebKit/537.36 (KHTML, like Gecko) " +
          "Chrome/131.0.0.0 Safari/537.36",
      },
      timeout: 30000,
    });

    const $ = cheerio.load(html);

    const news = [];

    $(".content-section a[href]").each((_, el) => {
      const link = $(el);

      const title = link.find("h3, p").first().text().trim();
      const href = link.attr("href");

      if (!title || !href) return;

      if (
        href.startsWith("/collection/") ||
        href.startsWith("#") ||
        href.startsWith("javascript:")
      ) {
        return;
      }

      const slug = new URL(
        href,
        "https://www.dinamani.com"
      ).pathname;

      if (!news.some((item) => item.slug === slug)) {
        news.push({
          title,
          slug,
        });
      }
    });

    // title~~slug,title~~slug
    const output = news
      .map((item) => `${item.title}~${item.slug}`)
      .join(",");

    res.set("Content-Type", "text/plain; charset=utf-8");

    return res.send(output);

  } catch (error) {
    console.error("Get news error:", error.message);

    return res.status(500).json({
      error: "Failed to fetch news",
      message: error.message,
    });
  }
};

module.exports = {
  getNews,
};